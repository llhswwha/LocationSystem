﻿/*************************************************************************************

   Extended WPF Toolkit

   Copyright (C) 2007-2013 Xceed Software Inc.

   This program is provided to you under the terms of the Microsoft Public
   License (Ms-PL) as published at http://wpftoolkit.codeplex.com/license 

   For more features, controls, and fast professional support,
   pick up the Plus Edition at http://xceed.com/wpf_toolkit

   Stay informed: follow @datagrid on Twitter or Like http://facebook.com/datagrids

  ***********************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace Xceed.Wpf.DataGrid
{
  internal sealed class DataGridItemContainerManager
  {
    #region Constructor

    internal DataGridItemContainerManager( IDataGridItemContainer owner )
    {
      if( owner == null )
        throw new ArgumentNullException( "owner" );

      if( !( owner is FrameworkElement ) )
        throw new ArgumentException( "The owner must derive from FrameworkElement.", "owner" );

      m_owner = owner;
    }

    #endregion

    internal void Prepare( DataGridContext dataGridContext, object dataItem )
    {
      m_containersPrepared = true;
      m_dataGridContext = dataGridContext;
      m_dataItem = dataItem;

      this.Update();
    }

    internal void Clear()
    {
      m_containersPrepared = false;
      m_dataGridContext = null;
      m_dataItem = null;

      try
      {
        this.ClearContainers();
      }
      finally
      {
        m_unpreparedContainers.Clear();
        m_preparedContainers.Clear();
      }
    }

    internal void Update()
    {
      var newContainers = m_owner.GetTemplatedChildDataGridItemContainers().ToList();

      try
      {
        this.ClearContainers( newContainers );
      }
      finally
      {
        foreach( var container in newContainers )
        {
          if( m_preparedContainers.Contains( container ) || m_unpreparedContainers.Contains( container ) )
            continue;

          m_unpreparedContainers.Add( container );
        }
      }

      this.PrepareContainers();
    }

    private void PrepareContainers()
    {
      if( !m_containersPrepared )
        return;

      foreach( var container in m_unpreparedContainers.ToList() )
      {
        m_unpreparedContainers.Remove( container );
        m_preparedContainers.Add( container );

        // Row based objects apply their template through their implementation of PrepareContainer.
        // No need to call ApplyTemplate beforehand.
        var row = container as Row;
        if( row == null )
        {
          var fe = container as FrameworkElement;
          if( fe != null )
          {
            fe.ApplyTemplate();
          }
        }
        else
        {
          // When dealing with a row, make sure its cells are properly initialized with their corresponding columns.
          row.SynchronizeCellsWithColumns( m_dataGridContext.DataGridControl, null, false );
        }

        container.PrepareContainer( m_dataGridContext, m_dataItem );
      }
    }

    private void ClearContainers()
    {
      this.ClearContainers( new List<IDataGridItemContainer>( 0 ) );
    }

    private void ClearContainers( ICollection<IDataGridItemContainer> keep )
    {
      foreach( var container in m_unpreparedContainers.Except( keep ).ToList() )
      {
        m_unpreparedContainers.Remove( container );

        var row = container as Row;
        if( row != null )
        {
          row.ClearCellsHost();
        }
      }

      foreach( var container in m_preparedContainers.Except( keep ).ToList() )
      {
        m_preparedContainers.Remove( container );

        container.ClearContainer();
      }
    }

    #region Private Fields

    private readonly IDataGridItemContainer m_owner;
    private readonly ICollection<IDataGridItemContainer> m_unpreparedContainers = new HashSet<IDataGridItemContainer>();
    private readonly ICollection<IDataGridItemContainer> m_preparedContainers = new HashSet<IDataGridItemContainer>();

    private DataGridContext m_dataGridContext;
    private object m_dataItem;
    private bool m_containersPrepared; //false

    #endregion
  }
}
